<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "form";

$connection = mysqli_connect($host, $user, $password, $database) ;


